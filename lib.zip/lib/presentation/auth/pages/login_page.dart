// lib/presentation/auth/pages/login_page.dart
import 'package:cosmicscans/app/routes/app_router.dart';
import 'package:cosmicscans/presentation/shared/styles/app_colors.dart';
import 'package:cosmicscans/presentation/shared/styles/app_text_styles.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  bool _rememberMe = false;
  bool _isPasswordVisible = false;

  bool _isSignInActive = true;

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 32.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const SizedBox(height: 40),
              // Logo Cosmic Toon
              Image.asset('assets/images/cosmic_toon_logo.png', height: 80),
              const SizedBox(height: 60),

              // Custom Toggle Sign In / Sign Up
              Container(
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [
                      AppColors.buttonGradientStart,
                      AppColors.buttonGradientEnd,
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(30.0),
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: GestureDetector(
                        onTap: () {
                          setState(() {
                            _isSignInActive = true;
                          });
                        },
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 300),
                          curve: Curves.easeInOut,
                          height: 50,
                          decoration: BoxDecoration(
                            color: _isSignInActive
                                ? AppColors.primary
                                : Colors.transparent,
                            borderRadius: BorderRadius.circular(30.0),
                          ),
                          alignment: Alignment.center,
                          child: Text(
                            'Sign In',
                            style: AppTextStyles.buttonText.copyWith(
                              color: _isSignInActive
                                  ? AppColors.textLight
                                  : AppColors.textGrey,
                            ),
                          ),
                        ),
                      ),
                    ),
                    Expanded(
                      child: GestureDetector(
                        onTap: () {
                          context.push(AppRoutes.registerPath).then((_) {
                            setState(() {
                              _isSignInActive = true;
                            });
                          });
                        },
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 300),
                          curve: Curves.easeInOut,
                          height: 50,
                          decoration: BoxDecoration(
                            color: _isSignInActive
                                ? Colors.transparent
                                : AppColors.primary,
                            borderRadius: BorderRadius.circular(30.0),
                          ),
                          alignment: Alignment.center,
                          child: Text(
                            'Sign Up',
                            style: AppTextStyles.buttonText.copyWith(
                              color: _isSignInActive
                                  ? AppColors.textGrey
                                  : AppColors.textLight,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 40),

              // Bagian Form Sign In
              _buildSignInForm(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSignInForm() {
    return Column(
      children: [
        // Email Input
        TextField(
          controller: _emailController,
          style: AppTextStyles.bodyText1,
          keyboardType: TextInputType.emailAddress,
          decoration: const InputDecoration(
            labelText: 'Email',
            hintText: 'Enter your email',
          ),
        ),
        const SizedBox(height: 20),

        // Password Input (MODIFIKASI UTAMA DI SINI)
        TextField(
          controller: _passwordController,
          style: AppTextStyles.bodyText1,
          obscureText: !_isPasswordVisible,
          decoration: InputDecoration(
            labelText: 'Password',
            hintText: 'Enter your password',
            // --- AWAL PERBAIKAN UNTUK OVERFLOW ---
            suffixIcon: Padding(
              padding: const EdgeInsets.only(right: 12.0),
              child: IconButton(
                icon: Icon(
                  _isPasswordVisible ? Icons.visibility : Icons.visibility_off,
                  color: AppColors.textGrey,
                  size: 24.0,
                ),
                onPressed: () {
                  setState(() {
                    _isPasswordVisible = !_isPasswordVisible;
                  });
                },
                splashRadius: 20.0,
                visualDensity: VisualDensity.compact,
              ),
            ),

            // --- AKHIR PERBAIKAN ---
          ),
        ),
        const SizedBox(height: 20),

        // Remember Me & Forgot Password
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                SizedBox(
                  width: 40,
                  height: 24,
                  child: Checkbox(
                    value: _rememberMe,
                    onChanged: (bool? newValue) {
                      setState(() {
                        _rememberMe = newValue ?? false;
                      });
                    },
                    activeColor: AppColors.primary,
                    checkColor: AppColors.textLight,
                    fillColor: MaterialStateProperty.resolveWith((states) {
                      if (states.contains(MaterialState.selected)) {
                        return AppColors.primary;
                      }
                      return AppColors.inputFieldBackground;
                    }),
                    side: const BorderSide(color: AppColors.textGrey),
                  ),
                ),
                const SizedBox(width: 9),
                Text('Ingat Saya', style: AppTextStyles.bodyText2),
              ],
            ),
            TextButton(
              onPressed: () {
                // TODO: Implement Forgot Password navigation
              },
              child: Text(
                'Lupa Password ?',
                style: AppTextStyles.bodyText2.copyWith(
                  color: AppColors.primary,
                  fontSize: 13,
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 40),

        // Sign In Button
        _buildGradientButton(
          text: 'Sign In',
          onPressed: () {
            // TODO: Implement login logic
            print('Email: ${_emailController.text}');
            print('Password: ${_passwordController.text}');
            print('Remember Me: $_rememberMe');

            // Contoh navigasi ke Home setelah login berhasil (sementara)
            context.go(AppRoutes.homePath);
          },
        ),
      ],
    );
  }

  Widget _buildGradientButton({
    required String text,
    required VoidCallback onPressed,
  }) {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [AppColors.buttonGradientStart, AppColors.buttonGradientEnd],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(10.0),
      ),
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.transparent,
          shadowColor: Colors.transparent,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10.0),
          ),
          padding: const EdgeInsets.symmetric(vertical: 16.0),
        ),
        child: Text(text, style: AppTextStyles.buttonText),
      ),
    );
  }
}