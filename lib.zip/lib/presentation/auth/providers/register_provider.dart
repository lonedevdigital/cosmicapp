// lib/presentation/auth/providers/register_provider.dart
import 'package:flutter/material.dart';
import 'package:cosmicscans/core/network/api_client.dart';

class RegisterProvider extends ChangeNotifier {
  final ApiClient _apiClient = ApiClient();

  bool isLoading = false;
  String? errorMessage;

  Future<bool> register({
    required String email,
    required String username,
    required String password,
    String deviceId = "2",
  }) async {
    isLoading = true;
    errorMessage = null;
    notifyListeners();

    try {
      final response = await _apiClient.post(
        '/users/register',
        data: {
          'device_id': deviceId,
          'email': email,
          'username': username,
          'password': password,
        },
      );

      isLoading = false;
      notifyListeners();
      return true;
    } catch (e) {
      errorMessage = e.toString();
      isLoading = false;
      notifyListeners();
      return false;
    }
  }
}
