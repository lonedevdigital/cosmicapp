class ApiConfig {
  static const String baseUrl =
      "http://127.0.0.1:8000/api/"; // Pastikan ini akurat dari swagger.yml

  // Endpoint-endpoint spesifik (sesuai swagger.yml)
  static const String login = "/login";
  static const String register = "/register";
  static const String heroSlider = "/heroslider";
  static const String rekomendasi = "/rekomendasi";
  static const String popularToday = "/popularToday";
  static const String project = "/project";
  static const String latest = "/latest";
  static const String searchManga = "/searchManga";
  static const String bookmark = "/bookmark";
  static const String userProfile = "/userProfile";
  static String seriesDetail(String slug) => "/seriesDetail/$slug";
  static String readingPage(String slug) => "/readingPage/$slug";
}
