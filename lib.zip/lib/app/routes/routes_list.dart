// lib/app/routes/routes_list.dart
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import 'app_routes.dart';
import 'package:cosmicscans/presentation/splash/pages/splash_page.dart';
import 'package:cosmicscans/presentation/auth/pages/login_page.dart';
import 'package:cosmicscans/presentation/auth/pages/register_page.dart';
import 'package:cosmicscans/presentation/home/pages/home_page.dart';

final List<GoRoute> appRoutes = [
  GoRoute(
    path: AppRoutes.splash,
    builder: (context, state) => const SplashPage(),
  ),
  GoRoute(
    path: AppRoutes.login,
    builder: (context, state) => const LoginPage(),
  ),
  GoRoute(
    path: AppRoutes.register,
    builder: (context, state) => const RegisterPage(),
  ),
  GoRoute(
    path: AppRoutes.home,
    builder: (context, state) => const HomePage(),
  ),

  // Tambahkan rute lain di sini sesuai fitur (search, detail, dsb)
];
