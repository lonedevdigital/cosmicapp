// lib/app/routes/app_router.dart
import 'package:go_router/go_router.dart';
import 'routes_list.dart';

final GoRouter router = GoRouter(
  initialLocation: '/',
  routes: appRoutes,
  errorBuilder: (context, state) => const Scaffold(
    body: Center(child: Text("Halaman tidak ditemukan")),
  ),
);
