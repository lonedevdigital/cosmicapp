import 'package:cosmicscans/domain/entities/user.dart'; // Import entitas User
import 'package:json_annotation/json_annotation.dart';

part 'user_model.g.dart';

@JsonSerializable()
class UserModel extends User {
  const UserModel({
    required super.userId, // Dari UserResponse
    required super.username,
    required super.email,
    super.deviceId, // Dari UserResponse
  });

  factory UserModel.fromJson(Map<String, dynamic> json) =>
      _$UserModelFromJson(json);
  Map<String, dynamic> toJson() => _$UserModelToJson(this);

  // Helper factory untuk mengadaptasi dari response API
  factory UserModel.fromProfileResponse(Map<String, dynamic> json) {
    return UserModel(
      userId:
          json['user_id'] as int, // Sesuaikan jika API mengembalikan user_id
      username: json['username'] as String,
      email: json['email'] as String,
      deviceId: json['deviceId'] as String?,
    );
  }
}
