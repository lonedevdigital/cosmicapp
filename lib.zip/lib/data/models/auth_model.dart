import 'package:cosmicscans/domain/entities/auth.dart'; // Import entitas Auth (akan kita buat)
import 'package:json_annotation/json_annotation.dart';

part 'auth_model.g.dart';

@JsonSerializable()
class AuthModel extends Auth {
  const AuthModel({
    required super.accessToken,
    required super.tokenType,
    required super.expiresIn,
  });

  factory AuthModel.fromJson(Map<String, dynamic> json) =>
      _$AuthModelFromJson(json);
  Map<String, dynamic> toJson() => _$AuthModelToJson(this);
}
