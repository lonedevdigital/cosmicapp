import 'package:cosmicscans/app/app.dart'; // Mengimport MyApp dari struktur aplikasi kita
import 'package:flutter/material.dart';
// import 'package:cosmicscans/app/config/app_theme.dart'; // Tidak diperlukan lagi di sini karena sudah diimpor di app.dart

void main() {
  // Pastikan Flutter binding sudah diinisialisasi sebelum menjalankan app
  // Ini penting jika Anda akan melakukan inisialisasi async (misal: SharedPreferences, GetIt) sebelum runApp.
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MyApp()); // Menjalankan widget MyApp dari struktur aplikasi kita
}
